1. Copy the Ironside folder to your <Cognos 8>\webcontent directory.
2. Import the Ironside Templates.zip deployment archive into your cognos environment.

For more information visit http://www.ironsidegroup.com